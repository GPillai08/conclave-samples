// Console_md.c #includes "Wincon.h", which only matches "wincon.h" on
// a case insensive filesystem, so we redirect here.
#include "wincon.h"
