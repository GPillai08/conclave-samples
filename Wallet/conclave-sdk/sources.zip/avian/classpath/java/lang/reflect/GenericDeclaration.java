package java.lang.reflect;

public interface GenericDeclaration {
  TypeVariable<?>[] getTypeParameters();
}
