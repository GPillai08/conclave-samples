/* Copyright (c) 2008-2015, Avian Contributors

   Permission to use, copy, modify, and/or distribute this software
   for any purpose with or without fee is hereby granted, provided
   that the above copyright notice and this permission notice appear
   in all copies.

   There is NO WARRANTY for this software.  See license.txt for
   details. */

package java.io;

import java.nio.channels.FileChannel;
import java.io.FileDescriptor;

public class FileInputStream extends InputStream {

  private InputStream inputStream;
  private FileDescriptor fd;

  public FileInputStream(String path) throws FileNotFoundException {
    if (path == null) {
      throw new NullPointerException();
    }
    this.inputStream = ClassLoader.getSystemClassLoader().getResourceAsStream(path);
    if (this.inputStream == null) {
        throw new FileNotFoundException(path);
    }
  }

  public FileInputStream(File file) throws FileNotFoundException {
    String path = (file != null) ? file.getPath() : null;
    if (path == null) {
      throw new NullPointerException("Invalid input file");
    }
    this.inputStream = ClassLoader.getSystemClassLoader().getResourceAsStream(path);
    if (this.inputStream == null) {
      throw new FileNotFoundException(path);
    }
  }
  public FileInputStream(FileDescriptor fd) throws IOException {
    // Called by JVM intialization, instances are discarded later
    this.fd = fd;
  }

  private void open(String s) {
  }

  public int read() throws IOException {
    check();
    byte[] output = new byte[1];
    inputStream.read(output);
    return output[1];
  }

  public int read(byte[] bytes) throws IOException {
    check();
    return inputStream.read(bytes);
  }

  public int read(byte[] bytes, int offset, int length) throws IOException  {
    check();
    return inputStream.read(bytes, offset, length);
  }

  public long skip(long length) throws IOException  {
    throw new UnsupportedOperationException();
  }

  public int available() throws IOException  {
    throw new UnsupportedOperationException();
  }

  public void close() throws IOException {
    check();
    inputStream.close();
  }

  public final FileDescriptor getFD() {
    return fd;
  }

  public FileChannel getChannel() {
    return null;
  }

  // Check this instance has not been constructed with a file descriptor
  private void check() throws IOException {
    if (inputStream == null) {
      throw new IOException("operations on FileDescriptor not supported");
    }
  }
}
