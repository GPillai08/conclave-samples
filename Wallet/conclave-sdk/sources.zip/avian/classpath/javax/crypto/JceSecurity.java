package javax.crypto;

import java.util.*;
import java.util.jar.*;
import java.io.*;
import java.net.URL;
import java.nio.file.*;
import java.security.*;

import java.security.Provider.Service;

import sun.security.jca.*;
import sun.security.jca.GetInstance.Instance;
import sun.security.util.Debug;

/**
 * A stripped down version of JceSecurity with security checks disabled.
 */
class JceSecurity {

    static final SecureRandom RANDOM = new SecureRandom();

    private static CryptoPermissions defaultPolicy = null;
    private static CryptoPermissions exemptPolicy = null;

    static {
        defaultPolicy = new CryptoPermissions();
        defaultPolicy.add(CryptoAllPermission.INSTANCE);
        exemptPolicy = new CryptoPermissions();
        exemptPolicy.add(CryptoAllPermission.INSTANCE);
    }

    static Instance getInstance(String type, Class<?> clazz, String algorithm, String provider)
            throws NoSuchAlgorithmException, NoSuchProviderException {
        Service s = GetInstance.getService(type, algorithm, provider);
        return GetInstance.getInstance(s, clazz);
    }

    static Instance getInstance(String type, Class<?> clazz, String algorithm, Provider provider)
            throws NoSuchAlgorithmException {
        Service s = GetInstance.getService(type, algorithm, provider);
        return GetInstance.getInstance(s, clazz);
    }

    static Instance getInstance(String type, Class<?> clazz, String algorithm)
            throws NoSuchAlgorithmException {
        List<Service> services = GetInstance.getServices(type, algorithm);
        NoSuchAlgorithmException failure = null;
        for (Service s : services) {
            try {
                Instance instance = GetInstance.getInstance(s, clazz);
                return instance;
            } catch (NoSuchAlgorithmException e) {
                failure = e;
            }
        }
        throw new NoSuchAlgorithmException("Algorithm " + algorithm
                + " not available", failure);
    }

    static CryptoPermissions verifyExemptJar(URL codeBase) throws Exception {
        CryptoPermissions all = new CryptoPermissions();
        all.add(CryptoAllPermission.INSTANCE);
        return all;
    }

    static void verifyProviderJar(URL codeBase) throws Exception { }

    static synchronized Exception getVerificationResult(Provider p) {
        return null;
    }

    static URL getCodeBase(final Class<?> clazz) {
            return null;
    }

    static boolean canUseProvider(Provider p) {
        return true;
    }

    static CryptoPermissions getDefaultPolicy() {
        return defaultPolicy;
    }

    static CryptoPermissions getExemptPolicy() {
        return exemptPolicy;
    }

    static boolean isRestricted() {
        return false;
    }
}
