package avian;

abstract class Code {
  // VM-visible fields in types.def
}
